
import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";

let users = [
  { email: "admin@txtblack.com", password: bcrypt.hashSync("gil102030", 10), role: "admin" },
];

export default NextAuth({
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const user = users.find(user => user.email === credentials?.email);
        if (user && bcrypt.compareSync(credentials?.password || "", user.password)) {
          return { email: user.email, role: user.role };
        }
        return null;
      },
    }),
  ],
  session: {
    strategy: "jwt",
  },
  pages: {
    signIn: "/auth/signin",
  },
});
